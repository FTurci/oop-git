#include <iostream>
#include "pgcalculator.h"

int main(int argc, char *argv[]) {

    PolygonCalculator calculator;  
    calculator.run() ;
    calculator.print();
    return 0;
}